<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\UserBank;
use App\Models\Transaction;

use Auth;

class TransactionController extends Controller
{
    public function getUserBank(Request $request) {
        $input = $request->all();

        $user_bank = UserBank::where([
            'user_id' => Auth::user()->id,
            'bank_id' => $input['bank_id']
        ])->first();

        return response()->json([
            'success' => true,
            'message' => 'Berhasil mendapatkan data bank pengguna',
            'data' => $user_bank->load('Bank:id,name')
        ], 200);
    }

    public function topup(Request $request) {
        $input = $request->all();
        $input['user_id'] = Auth::user()->id;

        // $user
    }

    public function getLastTransfer() {
        $last_transfer = Transaction::where('user_id', Auth::user()->id)->limit(3)->get();

        return response()->json([
            'success' => true,
            'message' => 'Berhasil mendapatkan data transfer terakhir',
            'data' => $last_transfer->load('UserBank:id,bank_id,account_name,rekening_number', 'UserBank.Bank:id,name')
        ]);
    }

    function getRekeningStatus(Request $request) {
        $input = $request->all();
        $user_bank = UserBank::where([
            'rekening_number' => $input['rekening_number'],
            'bank_id' => $input['bank_id']
        ])->first();
            
        if (!$user_bank) {
            return response()->json([
                'success' => false,
                'message' => 'Rekening tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'Berhasil mendapatkan data rekening pengguna',
            'data' => $user_bank->load('Bank:id,name')
        ], 200);
    }

    public function transfer(Request $request) {
        $input = $request->all();
        $input['user_id'] = Auth::user()->id;
        $input['transaction_code'] = 'tsd-'.rand(100, 999).'-'.rand(100, 999);
        $transaction = Transaction::create($input);

        return response()->json([
            'success' => true,
            'message' => 'Berhasil mentransfer',
            'data' => $transaction->load('User:id,firstname,lastname', 'UserBank:id,bank_id,account_name,rekening_number', 'UserBank.bank:id,name')
        ], 200);
    }

    public function getTransactionDetail(Request $request) {
        $transaction = Transaction::find($request->transaction_id);
        return response()->json([
            'success' => true,
            'message' => 'Berhasil mendapatkan data transfer',
            'data' => $transaction->load('User:id,firstname,lastname', 'UserBank:id,bank_id,account_name,rekening_number', 'UserBank.bank:id,name')
        ], 200);
    }
}
